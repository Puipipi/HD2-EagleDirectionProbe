Eagle Direction Probe v1.9.2 - corridor test candidate
=========================================================

WHAT THIS IS
  Draws the actual Eagle aircraft track, heading arrow and a warning strip at the
  settled stratagem beacon. Records positions for offline analysis. It does not
  modify gameplay values or use memory writes / HD2Runtime.
  Holographic style: white core, gently pulsing cyan borders/ribs, sparse ground
  chevrons, a landing diamond, a compact broad arrow and a dim flown trail.
  Ground and aircraft guides retire together on a confirmed departure climb,
  without waiting for the aircraft object to despawn. Live guide count has no
  numerical limit. Ground is 200 m long with a large forward arrow. The amber
  landing marker is upright as well as horizontal. The incoming stem extends
  220 m behind the aircraft; the arrow extends 120 m ahead.
  Warning lines disable depth occlusion by default. Terrain heights still come
  from local triangles of beacon samples, not a physics raycast. Sparse areas
  fall back to interpolation. No Runtime mod is required.

STATUS
  Test candidate, not validated in a real mission. Fixes a ground-segment colour
  key mismatch (nil passed to add_line in 1.7.0, all ground lines skipped in 1.8.0)
  and LuaJIT JSON serialization. Native crashes are not caught by pcall.
  The warning strip is not a measured damage footprint. Aircraft-to-beacon
  matching is heuristic; terrain heights are interpolated from beacon samples.
  Exact stratagem type is NOT identified: shared aircraft resources and zero
  munition-query hits cannot reliably distinguish Airstrike / Cluster / 500kg.

HOW TO USE
  1. Enable this mod and Bingus Shared Loader. Deploy. Start a mission.
  2. Call any Eagle stratagem (Airstrike, Cluster, Napalm, Strafing Run, Smoke,
     Gas, 110mm Rocket Pods) three or four times, FROM DIFFERENT ANGLES - vary the
     player-to-beacon bearing, or the analysis cannot tell the two candidate rules
     apart. 500kg is a single bomb with no run axis, so do not rely on it alone.
  3. Prefer OPEN TERRAIN for the baseline: the Eagle is reported to avoid
     obstacles, and a deflection would otherwise be mistaken for the rule being
     wrong. If you want to see that avoidance, deliberately call one strike toward
     a large piece of cover and remember which call it was.
  4. Verify a continuous white aircraft arrow and ground strip, then leave the
     mission. Check the log for errors. Samples are flushed during recording.

WHERE THE RESULTS GO
  %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\EagleDirectionProbe-<timestamp>.jsonl
      one JSON record per sample: beacon positions, Eagle unit positions and
      forward vectors. This is the file the offline analyzer reads.
  %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\EagleDirectionProbe.log
      human-readable: the stingray capability line, each call's start and end,
      and a shutdown summary.

  The first log line also settles a side question by measurement: whether the
  engine's `stingray` table is present independently of any other runtime mod.

IF THE EAGLE IS NEVER LISTED
  The probe finds the aircraft by the resource path
  content/fac_helldivers/vehicles/eagle/eagle. If the loader's resource query
  returns nothing for it, set FALLBACK_WORLD_SCAN = true near the top of the
  source and rebuild. That path walks the whole world (about 22,000 units) to
  find Eagle units by identity instead, in chunks of 2,000, and only while a call
  is live - it exists because the resource query is known to return an empty table
  for some units that do exist, and because walking the whole world while reading
  every position has crashed this game before.

IF A CALL LOOKS "WRONG"
  The Eagle is reported to avoid obstacles, so its approach direction changes when
  something is in the way. That means a strike that does not match the geometry is
  not automatically evidence that the geometry is wrong - it may be one deflected
  call. Note which calls were aimed toward large cover; the analyzer needs that
  from you, because the probe cannot see terrain.
