Eagle Direction Probe v1.10.0-rc3 - corridor test candidate
=========================================================

WHAT THIS IS
  Draws the actual Eagle aircraft track, heading arrow and a warning strip at the
  settled stratagem beacon. Records positions for offline analysis. It does not
  modify gameplay values or use memory writes / HD2Runtime.
  Holographic style: filled white arrows, cyan accents, small travelling ground
  arrows, a compact filled landing diamond and five moving UPRIGHT sky arrows.
  Each sky arrow is a single vertical plane with a shaft and pointed head (->),
  14 m long and 6.4 m tall. Its centre floats 12 m above cached terrain, without
  borders. Both ground/sky move 10 m/s; motion is cached at 20 Hz.
  Ground triangles are 5.2 m long and 5.8 m wide. White ground borders use three
  continuous strands over 0.5 m. Reference edges carry spaced upright red light
  panels per side, with a dim face, a bright baseline and a short upper bracket.
  Panels start 1.1 m above cached ground. The panel nearest the beacon carries
  a specific REF label when matched, or EAGLE ?. Panels and attached letters move
  forward at 10 m/s and wrap
  at corridor ends, using the 20 Hz motion cache and cached terrain heights.
  White borders/landing diamond stay static. No extra collision queries are made.
  EXPERIMENTAL TYPES: independent bounded active-record snapshots at 5 Hz with
  live guides. Two consecutive unique ball/record position matches identify a
  candidate among eight Eagle types. Ambiguity keeps EAGLE ?. No Runtime needed.
  Aircraft direction and retirement still use actual flight tracking.
  REF labels identify estimated reference footprints. Multi-bomb strips change
  length/width by type; strafe extends forward, 500kg uses a 25 m reference circle.
  These are NOT measured damage/safe boundaries. 110mm target remains unknown:
  its generic direction guide is retained, labelled 110MM TARGET ?.
  MOM options 具体飞鹰名称（测试） and 按战备调整参考范围（测试） default ON.
  They save independently; disabling both stops type reads.
  EXPERIMENTAL TRUE FILL: actual retained world-GUI triangles replace scan lines
  for aircraft arrows/shafts, sky shafts/heads, ground triangles, the diamond
  and moving panels.
  RC3 fixes swapped distance/height in rc1/rc2: the complete native path needs
  XYZ for creation and XZY for updates. Earlier tests stopped at the Lua wrapper
  and missed the shared native vertex writer. Material/depth still need validation.
  MOM: 真正面填充（测试） defaults ON in this candidate. Turn it OFF to restore
  the 1.9.10 line fill. Missing APIs also fall back. Enabling see-through forces
  the line path; no unverified world-GUI depth override is used.
  Faces reuse retained IDs, updating only on geometry changes. Ground faces use
  cached-height subdivisions and make no additional terrain collision queries.
  This is a separate test candidate; 1.9.10 remains the stable release.
  Ground and aircraft guides retire together on a confirmed departure climb,
  without waiting for the aircraft object to despawn. Live guide count has no
  numerical limit. Unknown/range-disabled ground is 200 m long and 12 m wide; known
  types use the reference bounds above. All its direction
  heads travel. The amber landing diamond is 2.8 m tall and wide. The stem extends
  220 m behind the aircraft; the arrow extends 120 m ahead.
  Ground/sky directions latch on low attack arrival after an observed descent:
  within 120 m horizontally and -30..130 m above this beacon. They no longer turn
  with pullout yaw that starts before the nose rises. Far approach stays live;
  the aircraft arrow keeps its live pose. Existing retirement timing is preserved.
  Coarse terrain mode queries the complete strip on a 10 m grid (63 points).
  All strips share a maximum of TWO queries per frame and a 0.5 ms soft budget.
  Heights are cached; small steering corrections do not restart sampling.
  Resumed beacon flight withdraws a provisional landing without retiring it.
  Resource query gaps may recover within the original unbound lifetime. A new
  throw from a retired object starts a fresh strike record.
  Unsampled/missed portions are omitted until valid heights are available.
  The amber upright marker stays at the actual beacon, including during sampling.
  Warning lines USE DEPTH TESTING by default (no see-through). If the guarded native query
  is unavailable, the old beacon interpolation is used and the reason is logged.
  No Runtime mod is required; no BTO mod is required at runtime.
  Separate thrown beacons own separate strips, independent of the logging call.
  Ground arrow sides also bend along the cached samples, without extra queries.
  The sky has arrows ONLY, no boundary. Five rigid glyph centres sit 12 m above
  their locally sampled surface (beacon height fallback), along the incoming axis.
  Sky brightness flows gently forward. Ground arrows travel at 10 m/s, with their
  geometry cached at 20 Hz separately from static outlines; no extra ray queries.
  Mod Options Menu (optional): MODS > 飞鹰方向指引. Toggles: 透视显示 (OFF by
  default), 飞鹰指示箭头 (ON), 天空方向箭头 (ON), 地面走廊边框 (ON),
  地面走廊三角 (ON), 红色全息警戒带 (ON), 真正面填充（测试） (ON),
  具体飞鹰名称（测试） (ON), 按战备调整参考范围（测试） (ON).
  The red tape follows the border switch.
  Click Apply; the menu saves choices. Either ground option
  shows the landing diamond. Hiding the aircraft arrow also hides its trail.
  Choices apply during a mission. Without the menu, these defaults are used.
  Saved choices are restored before synchronizing defaults, as in Stratagem Cooldown.
  Hiding both sky and ground stops new terrain queries.
  Ground geometry is cached independently of aircraft movement. Scalar height
  interpolation and shared animation signatures reduce Lua CPU/allocations;
  query budgets are preserved. New borders/triangles/tape/text increase default
  line submissions; actual game rendering cost is unverified. Motion also adds
  cached Lua geometry work. Disable the red tape option to reduce this work.

STATUS
  Test candidate, not validated in a real mission. Fixes a ground-segment colour
  key mismatch (nil passed to add_line in 1.7.0, all ground lines skipped in 1.8.0)
  and LuaJIT JSON serialization. Native crashes are not caught by pcall.
  The warning strip is not a measured damage footprint. Aircraft-to-beacon
  matching is heuristic. Collision sampling is coarse, and narrow rocks or sharp
  ridges between samples can still intersect the warning. Vertical queries can
  hit roofs/objects above the underlying terrain. It is not a terrain mesh.
  Only the audited current game build is supported by the native query. Different
  code/build/world/preset checks fail closed. No guessed native address is called.
  The soft budget cannot interrupt an individual native query. Actual game query
  timing and mission appearance still need verification; no FPS claim is made.
  Per-call type matching is spatial and experimental, not a unique native event ID.
  A confirmed label stays with its guide through record/query loss until guide
  retirement or a mission/world change. Unknown calls never inherit that label.
  Overlapping calls stay unknown. Reference lengths/widths are baseline estimates,
  not a measured full damage envelope; upgrades/scatter/targeting remain unverified.
  Eagle Storm is NOT mission-validated. Aircraft using the recognized resource
  can get air guides independently of beacons. Without an ordinary beacon there
  is no reliable ground landing point; nearest-aircraft matching remains heuristic.

HOW TO USE
  1. Enable this mod and Bingus Shared Loader. Deploy. Start a mission.
  2. Call any Eagle stratagem (Airstrike, Cluster, Napalm, Strafing Run, Smoke,
     Gas, 110mm Rocket Pods) three or four times, FROM DIFFERENT ANGLES - vary the
     player-to-beacon bearing, or the analysis cannot tell the two candidate rules
     apart. 500kg is a single bomb with no run axis, so do not rely on it alone.
  3. Prefer OPEN TERRAIN for the baseline: the Eagle is reported to avoid
     obstacles, and a deflection would otherwise be mistaken for the rule being
     wrong. If you want to see that avoidance, deliberately call one strike toward
     a large piece of cover and remember which call it was.
  4. Verify a continuous white aircraft arrow and ground strip, then leave the
     mission. Check the log for errors. Samples are flushed during recording.

WHERE THE RESULTS GO
  %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\EagleDirectionProbe-<timestamp>.jsonl
      one JSON record per sample: beacon positions, Eagle unit positions and
      forward vectors. This is the file the offline analyzer reads.
  %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\EagleDirectionProbe.log
      human-readable: the stingray capability line, each call's start and end,
      and a shutdown summary.
      Terrain diagnostics: attempts, hits, frame_max, query_peak and total_peak.

  The first log line also settles a side question by measurement: whether the
  engine's `stingray` table is present independently of any other runtime mod.

IF THE EAGLE IS NEVER LISTED
  The probe finds the aircraft by the resource path
  content/fac_helldivers/vehicles/eagle/eagle. If the loader's resource query
  returns nothing for it, set FALLBACK_WORLD_SCAN = true near the top of the
  source and rebuild. That path walks the whole world (about 22,000 units) to
  find Eagle units by identity instead, in chunks of 2,000, and only while a call
  is live - it exists because the resource query is known to return an empty table
  for some units that do exist, and because walking the whole world while reading
  every position has crashed this game before.

IF A CALL LOOKS "WRONG"
  The Eagle is reported to avoid obstacles, so its approach direction changes when
  something is in the way. That means a strike that does not match the geometry is
  not automatically evidence that the geometry is wrong - it may be one deflected
  call. Note which calls were aimed toward large cover; the analyzer needs that
  from you, because coarse vertical heights do not establish the damage footprint.
