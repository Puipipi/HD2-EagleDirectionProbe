Eagle Direction Probe v0.1.0 - READ-ONLY measurement addon
=========================================================

WHAT THIS IS
  A measurement instrument, not a gameplay mod. It answers one question: when an
  Eagle-series red stratagem is called, what is the aircraft's ACTUAL incoming
  direction, and how does that relate to the player and to the stratagem beacon?

  It draws nothing and grants nothing.

IT DOES NOT CHANGE ANYTHING
  * no memory writes of any kind
  * no native game function that mutates state is called
  * only read accessors on the game's own `stingray` table
  * every engine call is wrapped in pcall and cannot abort the update loop
  * writes exactly two files, both under the loader's own log directory
  * stops at a hard sample budget and says so

HOW TO USE
  1. Enable this mod and Bingus Shared Loader. Deploy. Start a mission.
  2. Call any Eagle stratagem (Airstrike, 500kg, Strafing Run, Cluster, Napalm,
     Smoke, Gas, 110mm Rocket Pods) three or four times, from different angles.
  3. Leave the mission. The probe flushes on shutdown.

WHERE THE RESULTS GO
  %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\EagleDirectionProbe.jsonl
      one JSON record per sample: beacon positions, Eagle unit positions and
      forward vectors. This is the file the offline analyzer reads.
  %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\EagleDirectionProbe.log
      human-readable: the stingray capability line, each call's start and end,
      and a shutdown summary.

  The first log line also settles a side question by measurement: whether the
  engine's `stingray` table is present independently of any other runtime mod.

IF THE EAGLE IS NEVER LISTED
  The probe finds the aircraft by the resource path
  content/fac_helldivers/vehicles/eagle/eagle. If the loader's resource query
  returns nothing for it, set FALLBACK_WORLD_SCAN = true near the top of the
  source and rebuild. That path walks the whole world (about 22,000 units) to
  find Eagle units by identity instead, in chunks of 2,000, and only while a call
  is live - it exists because the resource query is known to return an empty table
  for some units that do exist, and because walking the whole world while reading
  every position has crashed this game before.
